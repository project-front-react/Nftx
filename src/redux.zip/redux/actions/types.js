export const SET_LIGHT_MODE = 'LightMode'
export const SET_SWAP = 'SETSWAP'